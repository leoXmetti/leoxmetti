<div align="center">
  <img src=".github/workflows/name.svg" />
</div>

<div align="center">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=User-x-dev.User-x-dev&left_color=darkgoldenrod&right_color=darkgoldenrod&left_text=visitors%20"  />
  <a href="https://discord.com/users/1349828594863702129"><img src="https://raw.githubusercontent.com/Safouene1/support-palestine-banner/master/StandWithPalestine.svg"  />
</div>

<h2 align="left"></h2>

<div align="left">
  <a href="https://git.io/typing-svg" target="_blank" rel="noopener noreferrer">
    <img
      src="https://readme-typing-svg.demolab.com?font=Inconsolata&weight=800&pause=1000&color=b37f25&center=false&vCenter=false&width=535&lines=My+Discord+Account"
      alt="User x typing"
      style="border-radius: 20px; box-shadow: 0 0 25px rgba(142, 76, 247, 0.7);"
    />
  </a>
</div>

<div align="center">
<a href="https://discord.com/users/1349828594863702129"><img src="https://lanyard.cnrad.dev/api/1349828594863702129?showDisplayName=true&idleMessage=Coding...&theme=dark" /></a>
</div>

<h2 align="left"></h2>

<div align="left">
  <a href="https://git.io/typing-svg" target="_blank" rel="noopener noreferrer">
    <img
      <a href="https://discord.com/users/1349828594863702129"><img src="https://readme-typing-svg.demolab.com?font=Inconsolata&weight=800&pause=1000&color=b37f25&center=false&vCenter=false&width=535&lines=GitHub+Stats"
      alt="GitHub Stats"
      style="border-radius: 20px; box-shadow: 0 0 25px rgba(142, 76, 247, 0.7);"
    />
  </a>
</div>

<div align="center">
<img src="https://github-widgetbox.vercel.app/api/profile?username=User-x-dev&data=followers,repositories,stars,commits&theme=darkmode" /></a>
</div>

<h2 align="left"></h2>

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="40" alt="javascript logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" height="40" alt="typescript logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" height="40" alt="html5 logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" height="40" alt="css logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="40" alt="python logo"  />
  <img width="12" />
  <img src="https://cdn.simpleicons.org/nodedotjs/339933" height="40" alt="nodejs logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg" height="40" alt="cplusplus logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg" height="40" alt="linux logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg" height="40" alt="windows8 logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/android/android-original.svg" height="40" alt="android logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" height="40" alt="vscode logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/godot/godot-original.svg" height="40" alt="godot logo"  />
  <img width="12" />
  <img src="https://cdn.simpleicons.org/mongodb/47A248" height="40" alt="mongodb logo"  />
</div>

###

<h2 align="left"></h2>

###

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/User-x-dev/User-x-dev/output/pacman-contribution-graph-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/User-x-dev/User-x-dev/output/pacman-contribution-graph.svg">
  <img alt="pacman contribution graph" src="https://raw.githubusercontent.com/User-x-dev/User-x-dev/output/pacman-contribution-graph.svg">
</picture>
